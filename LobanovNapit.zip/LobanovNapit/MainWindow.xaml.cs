﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LobanovNapit
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        AvtomatEntities4 db = new AvtomatEntities4();
        int wallet = 0;
        public MainWindow()
        {
            InitializeComponent();
            
            DrinksList.ItemsSource = db.VendingMachineDrinks
            .Select(x => new
            {
                id = x.Id,
                Name = x.Drinks.Name,
                Price = x.Drinks.Cost +" руб."
            }).ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            int denomination = Convert.ToInt32(btn.Content);
            var Coin = db.VendingMachineCoins.FirstOrDefault(x => x.Coins.Denomination == denomination);
            if (Coin == null)
            {
                var newCoin = new VendingMachineCoins
                {
                    VendingMachinesId = 1,
                    VendingMachines = db.VendingMachines.FirstOrDefault(x => x.Id == 1),
                    Coins = db.Coins.FirstOrDefault(x => x.Denomination == denomination),
                    CoinsId = db.Coins.FirstOrDefault(x => x.Denomination == denomination).Id,
                    Count = 1,
                    IsActive = 1
                };
                if (db.VendingMachineCoins.ToList().Count == 0)
                {
                    newCoin.Id = 1;
                }
                else
                {
                    newCoin.Id = db.VendingMachineCoins.ToList().Max(point => point.Id) + 1;
                }
                db.VendingMachineCoins.Add(newCoin);
            } 
            else
            {
                Coin.Count++;
            }
            db.SaveChanges();
            wallet = wallet + denomination;
            edWallet.Content = Convert.ToString(wallet) + " руб.";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var coin1 = db.VendingMachineCoins.FirstOrDefault(x => x.Coins.Denomination == 1);
            var coin2 = db.VendingMachineCoins.FirstOrDefault(x => x.Coins.Denomination == 2);
            var coin5 = db.VendingMachineCoins.FirstOrDefault(x => x.Coins.Denomination == 5);
            var coin10 = db.VendingMachineCoins.FirstOrDefault(x => x.Coins.Denomination == 10);
            int walet10 = wallet / 10;
            if (walet10 > 0)
            {
                if (coin10.Count < walet10)
                { 
                }
                else
                {
                    coin10.Count = coin10.Count - walet10;
                    wallet = wallet - (walet10 * coin10.Coins.Denomination);
                    string wallet10 = Convert.ToString(walet10);
                }
            }
            MessageBox.Show("Сдача выдана в размере - " + wallet, "Сдача", MessageBoxButton.OK, MessageBoxImage.Information);
            wallet = 0;
            edWallet.Content = Convert.ToString(wallet) + " руб.";
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Window1 window = new Window1();
            window.ShowDialog();
        }

        private void ListBoxItem_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (DrinksList.SelectedValue != null)
            {
                System.Type type = DrinksList.SelectedValue.GetType();
                int TovarId = (int)type.GetProperty("id").GetValue(DrinksList.SelectedValue, null);
                var Tovar = db.VendingMachineDrinks.FirstOrDefault(x => x.Id == TovarId);

                var result = MessageBox.Show("Вы действительно хотите купить " + Tovar.Drinks.Name + " ?", "Покупка",
                                 MessageBoxButton.YesNo,
                                 MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    if (Tovar.Count == 0)
                    {
                        MessageBox.Show("Товар закончился", "Покупка", MessageBoxButton.OK, MessageBoxImage.Information);
                        return;
                    }

                    if (wallet < Tovar.Drinks.Cost)
                    {
                        MessageBox.Show("Недостаточно средств", "Покупка", MessageBoxButton.OK, MessageBoxImage.Information);
                        return;
                    }
                    Tovar.Count--;
                    wallet = wallet - Convert.ToInt32(Tovar.Drinks.Cost);
                    edWallet.Content = Convert.ToString(wallet) + " руб.";
                    db.SaveChanges();
                }
            }
        }
    }
}
